const cakes = [
  {
    title: 'Marble Cake',
    link: '/app/pages/product/details'
  },
  {
    title: 'Fruitcake',
    link: '/app/pages/product/details'
  },
  {
    title: 'Chocolate Cake',
    link: '/app/pages/product/details'
  },
  {
    title: 'Fat Rascal',
    link: '/app/pages/product/details'
  },
  {
    title: 'Financier',
    link: '/app/pages/product/details'
  },
  {
    title: 'Genoise',
    link: '/app/pages/product/details'
  },
  {
    title: 'Gingerbread',
    link: '/app/pages/product/details'
  },
  {
    title: 'Goose Breast',
    link: '/app/pages/product/details'
  },
  {
    title: 'Parkin',
    link: '/app/pages/product/details'
  },
  {
    title: 'Salzburger Nockerl',
    link: '/app/pages/product/details'
  },
  {
    title: 'Soufflé',
    link: '/app/pages/product/details'
  },
  {
    title: 'Merveilleux',
    link: '/app/pages/product/details'
  },
  {
    title: 'Streuselkuchen',
    link: '/app/pages/product/details'
  },
  {
    title: 'Tea Loaf',
    link: '/app/pages/product/details'
  },
  {
    title: 'Napoleonshat',
    link: '/app/pages/product/details'
  },
  {
    title: 'Merveilleux',
    link: '/app/pages/product/details'
  },
  {
    title: 'Magdalena',
    link: '/app/pages/product/details'
  },
  {
    title: 'Cremeschnitte',
    link: '/app/pages/product/details'
  },
  {
    title: 'Cheesecake',
    link: '/app/pages/product/details'
  },
  {
    title: 'Bebinca',
    link: '/app/pages/product/details'
  },
  {
    title: 'Fruitcake',
    link: '/app/pages/product/details'
  },
  {
    title: 'Chocolate Cake',
    link: '/app/pages/product/details'
  },
  {
    title: 'Fat Rascal',
    link: '/app/pages/product/details'
  },
  {
    title: 'Streuselkuchen',
    link: '/app/pages/product/details'
  }
]
export default cakes
